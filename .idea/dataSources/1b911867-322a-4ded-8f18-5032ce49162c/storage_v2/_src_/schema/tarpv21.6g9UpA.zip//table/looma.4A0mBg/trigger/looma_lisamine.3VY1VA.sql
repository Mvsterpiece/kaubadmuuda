create definer = root@localhost trigger looma_lisamine
    after insert
    on looma
    for each row
    INSERT INTO logs(kuupaev, kasutaja, andmed)
SELECT NOW(), USER(), CONCAT('lisatud loom on ',NEW.loomatuup,' ',NEW.nimi, 'Tervis: ',m.tervisID,' vanus: ', NEW.vanus)
FROM looma l
INNER JOIN tervis m ON l.tervisID = m.tervisID
WHERE l.loomaID  = NEW.loomaID;

