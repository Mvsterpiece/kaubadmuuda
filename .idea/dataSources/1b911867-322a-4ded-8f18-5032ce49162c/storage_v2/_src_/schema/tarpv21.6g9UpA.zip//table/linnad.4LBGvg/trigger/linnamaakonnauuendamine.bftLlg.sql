create definer = root@localhost trigger linnaMaakonnaUuendamine
    before update
    on linnad
    for each row
    INSERT INTO logs(kuupaev, kasutaja, andmed)
SELECT NOW(), USER(), CONCAT('lisatud linn on ',OLD.linn,' ', m.maakondID,' pindala: ', OLD.pindala,
'. Uued andmed: ',NEW.linn, ', ',m1.maakond, ', pindala: ',NEW.pindala)
FROM linnad l
INNER JOIN maakond m ON OLD.maakondID = m.maakondID
INNER JOIN maakond m1 ON NEW.maakondID = m1.maakondID
WHERE l.linnID = NEW.linnID;

