create definer = root@localhost trigger looma_kustutamine
    before delete
    on looma
    for each row
    INSERT INTO logs(kuupaev, kasutaja, andmed)
SELECT NOW(), USER(), CONCAT('kustutatud loom on ',OLD.loomatuup,' ',OLD.nimi, 'Tervis: ',m.tervisID,' vanus: ', OLD.vanus)
FROM looma l
INNER JOIN tervis m ON l.tervisID = m.tervisID
WHERE l.loomaID  = OLD.loomaID;

